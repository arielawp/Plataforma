<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stay extends Model
{
    //
}
