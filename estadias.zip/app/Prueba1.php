<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prueba1 extends Model
{
    //
}
