<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

<!-- Required meta tags -->
<meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
       <!-- Bootstrap CSS -->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.ripples/0.5.3/jquery.ripples.min.js"></script>
    <!-- links -->

    <link rel="stylesheet" href="<?php echo e(asset('css/vista.css')); ?>">



    <title>Admin</title>
</head>
<body>
<div class="full-landing-image">
<center>        <a type="button" href="<?php echo e(url('usuario/create')); ?>" class="btn btn-primary" style="padding:20px; font-size:2vw; border-radius: 20px solid #fff; border-bottom: 20px solid #fff; text-align: center; position: 50% 50%;">Empezemos</a>
</center>
      
    </div>
   

    <script>
      $(".full-landing-image").ripples({
        resolution: 256,
        perturbance: 0.04,
      });
      </script>

</body>
</html>

<?php /**PATH /var/www/html/estadias/resources/views/vista.blade.php ENDPATH**/ ?>