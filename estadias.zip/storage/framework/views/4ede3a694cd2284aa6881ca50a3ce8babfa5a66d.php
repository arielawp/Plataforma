<?php $__env->startSection('content'); ?>

<H1 class="text-center">&copy; ariel</H1>
<div class="container">

    
<a class="btn btn-primary" href="<?php echo e(route('Diseño.create')); ?>">Asignar proyecto</a>
<a class="btn btn-primary mb-3 float-right" href="">Imprimir</a>





<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nombre del proyecto</th>
      <th scope="col">Actividad</th>
      <th scope="col">inicio del proyecto</th>
      <th scope="col">Fin del proyecto</th>
      <th scope="col">Tiempo estimado de la actividad</th>
      <th scope='col'>Fecha</th>
      <th scope='col'>Terminado</th>
      <th scope='col'>Comentarios</th>
      <th scope='col'>Acciones</th>
      

    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $disenos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diseno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($diseno->id); ?></th>
      <td><?php echo e($diseno->nombre); ?></td>
      <td><?php echo e($diseno->actividad); ?></td>
      <td><?php echo e($diseno->inicio); ?></td>
      <td><?php echo e($diseno->fin); ?></td>
      <td><?php echo e($diseno->tiempo); ?></td>
      <td><?php echo e($diseno->fecha); ?></td>
      <td><?php echo e($diseno->terminado); ?></td>
      <td><?php echo e($diseno->comentarios); ?></td>

      <td><a class=" btn btn-info botoninput" href=" <?php echo e(route('Diseño.edit', $diseno->id)); ?>"><i class="primary"></i>
    </a>


</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php echo e($disenos->links()); ?>

</div>



<?php $__env->stopSection(); ?> 
<?php echo $__env->make('Diseño.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/estadias/resources/views/Diseño/index.blade.php ENDPATH**/ ?>