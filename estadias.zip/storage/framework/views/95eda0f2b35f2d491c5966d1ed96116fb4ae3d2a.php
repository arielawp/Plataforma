<?php $__env->startSection('content'); ?>
<div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                <form action="<?php echo e(route('auxiliar.update', $auxi->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="container">
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">Nombre</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="nombre" value=<?php echo e($text->nombre); ?> placeholder="inserta la visión" type="text" class="form-control">
                            </div>
                        </div>
                    </div>

                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">actividad</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="actiividad" value=<?php echo e($text->actividad); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">Hora de inicio</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="inicio" value=<?php echo e($text->inicio); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">fin</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="fin" value=<?php echo e($text->fin); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">tiempo</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="tiempo" value=<?php echo e($text->tiempo); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">fecha</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="fecha" value=<?php echo e($text->fecha); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">terminado</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="terminado" value=<?php echo e($text->terminado); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group row">
                        <label for="nombre" class="col-3 col-form-label">fecha</label>
                        <div class="col-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fa fa-address-card"></i>
                                    </div>
                                </div>
                                <input id="nombre" name="comentarios" value=<?php echo e($text->comentarios); ?> placeholder="inserta los valores" type="text" class="form-control">
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group">
                            <button name="submit" type="submit" class="btn btn-primary">Guardar</button>
                            <a class="btn btn-success float-right" href="<?php echo e(route('auxiliar.index')); ?>">Cancelar</a>
                    </div>
                </form>
            </div>  
         
                    </div>
                    
        </div>  
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auxiliar.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/estadias/resources/views/auxiliar/edit.blade.php ENDPATH**/ ?>