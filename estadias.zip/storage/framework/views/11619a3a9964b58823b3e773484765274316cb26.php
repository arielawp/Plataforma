<?php $__env->startSection('content'); ?>

<H1 class="text-center">&copy; ariel</H1>
<div class="container">

    
<a class="btn btn-primary" href="<?php echo e(route('menu.create')); ?>">Asignar proyecto</a>
<a class="btn btn-primary mb-3 float-right" href="  ">Imprimir</a>





<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nombre del proyecto</th>
      <th scope="col">Actividad</th>
      <th scope="col">inicio del proyecto</th>
      <th scope="col">Fin del proyecto</th>
      <th scope="col">Contador</th>
      <th scope="col">Tiempo estimado de la actividad</th>
      <th scope='col'>Fecha</th>
      <th scope='col'>Terminado</th>
      <th scope='col'>Comentarios</th>
      <th scope='col'>Acciones</th>
      

    </tr>
  </thead>
  <tbody>

  <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($menu->id); ?></th>
      <td><?php echo e($menu->nombre); ?></td>
      <td><?php echo e($menu->actividad); ?></td>
      <td><?php echo e($menu->inicio); ?></td>
      <td><?php echo e($menu->fin); ?></td>
      <td><?php echo e($menu->contador); ?></td>
      <td><?php echo e($menus=$menu->tiempo+$menu->tiempo); ?></td>
      <td><?php echo e($menu->fecha); ?></td>
      <td><?php echo e($menu->terminado); ?></td>
      <td><?php echo e($menu->comentarios); ?></td>

<!-- botones pra editar y eliminar -->
      <td><a class=" btn btn-info botoninput" href=" <?php echo e(route('menu.edit', $menu->id)); ?>"><i class="fas fa-edit"></i>
    </a>
    <form action="<?php echo e(route('menu.destroy',$text->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
          <button type="submit" class="btn-sm btn-danger mt-3" onclick="return confirm('Quiere borrar el registro?')" ><i class="far fa-trash-alt"></i></button>

        </form>

</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('menu.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/estadias/resources/views/menu/index.blade.php ENDPATH**/ ?>