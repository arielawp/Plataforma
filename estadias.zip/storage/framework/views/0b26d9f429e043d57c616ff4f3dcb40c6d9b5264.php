

<?php $__env->startSection('content'); ?>

<H1 class="text-center">&copy; ariel</H1>
<div class="container">

    
<a class="btn btn-primary" href="<?php echo e(route('books.create')); ?>">Asignar proyecto</a>
<a class="btn btn-primary mb-3 float-right" href="  ">Imprimir</a>
<br>
<br>


<?php if(Session::has('message')): ?>
      <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>







<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nombre del proyecto</th>
      <th scope="col">Actividad</th>
      <th scope="col">inicio del proyecto</th>
      <th scope="col">Fin del proyecto</th>
      <th scope="col">Tiempo estimado de la actividad</th>
      <th scope='col'>Fecha</th>
      <th scope='col'>Terminado</th>
      <th scope='col'>Comentarios</th>
      <th scope='col'>Acciones</th>
      

    </tr>
  </thead>
  <tbody>

  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($book->id); ?></th>
      <td><?php echo e($book->nombre); ?></td>
      <td><?php echo e($book->actividad); ?></td>
      <td><?php echo e($book->inicio); ?></td>
      <td><?php echo e($book->fin); ?></td>
      <td><?php echo e($books = $book->tiempo + $book); ?></td>
      

      <td><?php echo e($book->fecha); ?></td>
      <td><?php echo e($book->terminado); ?></td>
      <td><?php echo e($book->comentarios); ?></td>


      <td><a class=" btn btn-info botoninput" href=" <?php echo e(route('books.edit', $book->id)); ?>"><i class="fas fa-edit"></i>
    </a>
    <form action="<?php echo e(route('books.destroy',$book->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
          <button type="submit" class="btn-sm btn-danger mt-3" onclick="return confirm('Quiere borrar el registro?')" ><i class="far fa-trash-alt"></i></button>

        </form>

</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>




<?php $__env->stopSection(); ?> 
<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/estadias/resources/views/books/index.blade.php ENDPATH**/ ?>