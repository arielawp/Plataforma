	<?php $__env->startSection('content'); ?>
	<?php echo Form::open(['route'=>'usuario.store', 'method'=>'POST']); ?>

	<H1 class="text-center">&copy; <strong>Todos los derechos reservados Novemp 2019 </strong> </H1>

	<div class="form-group">
		<?php echo Form::label('nombre','Nombre:'); ?>

		<?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Ingresa el Nombre del usuario']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('email','Correo:'); ?>

		<?php echo Form::text('email',null,['class'=>'form-control','placeholder'=>'Ingresa el Nombre del usuario']); ?>

	</div>
	<div class="form-group">
		<?php echo Form::label('password','Contraseña:'); ?>

		<?php echo Form::password('password',['class'=>'form-control','placeholder'=>'Ingresa el Nombre del usuario']); ?>

	</div>


	<?php echo Form::submit('Registrar',['class'=>'btn btn-primary']); ?>

	<a href="<?php echo e(url ('/')); ?>">Regresar</a>
	<?php echo Form::close(); ?>

	<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/estadias/resources/views/usuario/create.blade.php ENDPATH**/ ?>